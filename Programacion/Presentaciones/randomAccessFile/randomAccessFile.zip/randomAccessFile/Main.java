package randomAccessFile;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);
	static RandomAccessFile fichero = null;

	public static void main(String[] args) {

		int numero;

		try {
			// se abre el fichero para lectura y escritura
			fichero = new RandomAccessFile("./Rafa.dat", "rw");

			Gestion.mostrarFichero(fichero); 	// muestra el contenido original
												// del fichero

			System.out.print("Introduce un número entero para añadir al final del fichero: ");

			numero = sc.nextInt(); 				// se lee el entero a añadir en el fichero

			fichero.seek(fichero.length()); 	// nos situamos al final del fichero

			fichero.writeInt(numero); 			// se escribe el entero

			Gestion.mostrarFichero(fichero); 	// muestra el contenido del fichero
												// después de añadir el
												// número

		} catch (FileNotFoundException ex) {
			System.out.println(ex.getMessage());
		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		} finally {
			try {
				if (fichero != null) {
					fichero.close();
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
}
