package randomAccessFile;

import java.io.EOFException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Gestion {

	public static void mostrarFichero(RandomAccessFile fichero) {
        int n;
        
        try {
            fichero.seek(0); //nos situamos al principio
            
            while (fichero.getFilePointer() < fichero.length()) { /*getFilePointer--Puntero leyendo el fichero en bytes.*/
            	
                n = fichero.readInt();  //se lee  un entero del fichero
                
                System.out.println(n);  //se muestra en pantalla
            }
            
        } catch (EOFException e) {
        	
            System.out.println("Fin de fichero");
            
        } catch (IOException ex) {
        	
            System.out.println(ex.getMessage());
        }
    }
	
}
