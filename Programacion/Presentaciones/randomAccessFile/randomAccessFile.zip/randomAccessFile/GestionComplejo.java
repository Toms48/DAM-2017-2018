package randomAccessFile;

import java.io.EOFException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class GestionComplejo {

	
	public static void mostrarFichero(RandomAccessFile fichero) {
		
        String s;
        char c;
        int i;
        
        try {
        	
            fichero.seek(0); //nos situamos al principio
            
            while (fichero.getFilePointer() < fichero.length()) { /*getFilePointer--Puntero leyendo el fichero en bytes.*/
            	
            	s = fichero.readUTF();  //se lee  un entero del fichero
            	c = fichero.readChar();
            	i = fichero.readInt();
                
                System.out.println(s + ", " + c + ", " + i);  //se muestra en pantalla
            }
            
        } catch (EOFException e) {
        } catch (IOException e) {
        	
            System.out.println("Fin de fichero");
        }
    }
    
    
	public static void buscarPorNombre(RandomAccessFile fichero, String Nombre) {

		String s = "null";
		char c = 'n';
		int i = -100;

		boolean encontrado = false;

		try {

			fichero.seek(0);

			while (fichero.getFilePointer() < fichero.length() && !encontrado) {

				s = fichero.readUTF();  //COMENTAR QUE PASA SI SE LEEN LOS DEM�S ATRIBUTOS

				if (s.equals(Nombre)) {
					encontrado = true;
				} else {
					fichero.skipBytes(6);
				}
			}
		} catch (IOException e) {
			//System.out.println("");
		}

		if (encontrado) {
			System.out.println("Lo hemos encontrado!");
		} else {
			System.out.println("HEMOSIDOENGA�ADO");
		}

	}

}
