package randomAccessFile;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class MainComplejo {

	public static void main(String[] args) {

		RandomAccessFile miFichero = null;

		try {
			miFichero = new RandomAccessFile("./RafaSkip.dat", "rw");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		try {
			miFichero.writeUTF("Luis");
			miFichero.writeChar('H');
			miFichero.writeInt(-6);

			miFichero.writeUTF("Rafael Mateos");
			miFichero.writeChar(66);
			miFichero.writeInt(8);

			miFichero.writeUTF("William Wonka");
			miFichero.writeChar(67);
			miFichero.writeInt(9);
			
			miFichero.writeUTF("Alfredo");
			miFichero.writeChar(67);
			miFichero.writeInt(9);
			
			miFichero.writeUTF("Compadre");
			miFichero.writeChar(67);
			miFichero.writeInt(9);
			
			miFichero.writeUTF("Espeto patronum");
			miFichero.writeChar(67);
			miFichero.writeInt(9);

		} catch (IOException e) {
			e.printStackTrace();
		}

		GestionComplejo.mostrarFichero(miFichero);

		// MostrarFlama("Luis");
		
		GestionComplejo.buscarPorNombre(miFichero, "Luis");
		GestionComplejo.buscarPorNombre(miFichero, "William Wonka");
		GestionComplejo.buscarPorNombre(miFichero, "Ildefonso Coca Merida");

	}
}
